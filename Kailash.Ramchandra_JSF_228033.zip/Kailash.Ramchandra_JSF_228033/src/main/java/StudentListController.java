

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

/**
 * Servlet implementation class StudentListController
 */
@WebServlet("/studentList")  // New servlet for student list
public class StudentListController extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private StudentDao studentDao = new StudentDao(); // Use the DAO to fetch students

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            List<Student> students = studentDao.getAllStudents();
            request.setAttribute("students", students);  // Set students as an attribute
            request.getRequestDispatcher("/studentList.jsp").forward(request, response);  // Forward to the JSP page
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Error fetching student data from database");
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }
    }
}