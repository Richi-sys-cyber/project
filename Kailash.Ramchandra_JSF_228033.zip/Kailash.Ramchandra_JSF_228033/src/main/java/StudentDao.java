import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class StudentDao {
	  private static final String JDBC_URL = "jdbc:mysql://localhost:3306/user";
	    private static final String JDBC_USER = "root";
	    private static final String JDBC_PASSWORD = "root";

	    static {
	        try {
	            // Manually register the PostgreSQL JDBC driver
	            Class.forName("com.mysql.cj.jdbc.Driver");
	        } catch (ClassNotFoundException e) {
	            e.printStackTrace();
	        }
	    }

	    // SQL queries for CRUD operations
	    private static final String INSERT_STUDENT_SQL =
	            "INSERT INTO user.students (name, username, password, gender, skills, contact, email, college) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
	    private static final String SELECT_ALL_STUDENTS_SQL =
	            "SELECT * FROM user.students";

	    // Method to insert a new student into the database
	    public void insertStudent(Student student) throws SQLException {
	        try (Connection connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
	             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_STUDENT_SQL)) {

	            preparedStatement.setString(1, student.getName());
	            preparedStatement.setString(2, student.getUsername());
	            preparedStatement.setString(3, student.getPassword());
	            preparedStatement.setString(4, student.getGender());
	            preparedStatement.setString(5, student.getSkills());
	            preparedStatement.setString(6, student.getContact());
	            preparedStatement.setString(7, student.getEmail());
	            preparedStatement.setString(8, student.getCollege());

	            preparedStatement.executeUpdate();
	        }
	    }

	    public List<Student> getAllStudents() throws SQLException {
	        List<Student> students = new ArrayList<>();

	        try (Connection connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
	             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_STUDENTS_SQL)) {

	            try (ResultSet resultSet = preparedStatement.executeQuery()) {
	                while (resultSet.next()) {
	                    String name = resultSet.getString("name");
	                    String username = resultSet.getString("username");
	                    String password = resultSet.getString("password");
	                    String gender = resultSet.getString("gender");
	                    String skills = resultSet.getString("skills");
	                    String contact = resultSet.getString("contact");
	                    String email = resultSet.getString("email");
	                    String college = resultSet.getString("college");
	                  //  System.out.println("Name"+ name);


	                    students.add(new Student(name, username, password, gender, skills, contact, email, college));
	                }
	            }
	        }
	     //   System.out.println("students"+ students);
	        return students;
	    }

	    // Method to get all students based on a username
	    
	    public List<Student> getStudentsByUsername(String username) throws SQLException {
	    	
	        List<Student> students = new ArrayList<>();

	        try (Connection connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
	             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_STUDENTS_SQL)) {

	            preparedStatement.setString(1, username);

	            try (ResultSet resultSet = preparedStatement.executeQuery()) {
	                while (resultSet.next()) {
	                    String name = resultSet.getString("name");
	                    String user = resultSet.getString("username");
	                    String password = resultSet.getString("password");
	                    String gender = resultSet.getString("gender");
	                    String skills = resultSet.getString("skills");
	                    String contact = resultSet.getString("contact");
	                    String email = resultSet.getString("email");
	                    String college = resultSet.getString("college");
	

	                    students.add(new Student(name, user, password, gender, skills, contact, email, college));
	                }
	            }
	        }
	        return students;
	    }
}
