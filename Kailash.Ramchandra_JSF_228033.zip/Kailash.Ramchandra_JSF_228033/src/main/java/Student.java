
public class Student {
	
	    private String name;
	    private String username;
	    private String password;
	    private String gender;
	    private String skills;
	    private String contact;
	    private String email;
	    private String college;

	    // Constructor, getters, and setters
	    public Student(String name, String username, String password, String gender, String skills,
	                   String contact, String email, String college) {
	        this.name = name;
	        this.username = username;
	        this.password = password;
	        this.gender = gender;
	        this.skills = skills;
	        this.contact = contact;
	        this.email = email;
	        this.college = college;
	    }

	    public String getName() {
	        return name;
	    }

	    public String getUsername() {
	        return username;
	    }

	    public String getPassword() {
	        return password;
	    }

	    public String getGender() {
	        return gender;
	    }

	    public String getSkills() {
	        return skills;
	    }

	    public String getContact() {
	        return contact;
	    }

	    public String getEmail() {
	        return email;
	    }

	    public String getCollege() {
	        return college;
	    }

	    @Override
	    public String toString() {
	        return "Student{" +
	                "name='" + name + '\'' +
	                ", username='" + username + '\'' +
	                ", password='" + password + '\'' +
	                ", gender='" + gender + '\'' +
	                ", skills=" + skills +
	                ", contact='" + contact + '\'' +
	                ", email='" + email + '\'' +
	                ", college='" + college + '\'' +
	                '}';
	    }
	}

