

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

/**
 * Servlet implementation class StudentController
 */
@WebServlet("/register")
public class StudentController extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private StudentDao studentDao;

    @Override
    public void init() {
        studentDao = new StudentDao();  // Initialize StudentDao
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("/register.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String name = request.getParameter("name");
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String retypePassword = request.getParameter("retypePassword");
        String gender = request.getParameter("gender");
        String skills = "";
        String[] tmp = request.getParameterValues("skills");
        for (int i = 0; i < tmp.length; i++) {
            skills += tmp[i] + ",";
        }

        String contact = request.getParameter("contact");
        String email = request.getParameter("email");
        String college = request.getParameter("college");

        // Validation - check if passwords match
        if (!password.equals(retypePassword)) {
            request.setAttribute("error", "Passwords do not match!");
            request.getRequestDispatcher("/register.jsp").forward(request, response);
            return;
        }

        // Create a new Student object
        Student student = new Student(name, username, password, gender, skills.toString(), contact, email, college);
        try {
            // Insert the student into the database
            studentDao.insertStudent(student);
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Error saving student to the database.");
            request.getRequestDispatcher("/register.jsp").forward(request, response);
            return;
        }


        response.sendRedirect(request.getContextPath() + "/studentList");
    }
}

