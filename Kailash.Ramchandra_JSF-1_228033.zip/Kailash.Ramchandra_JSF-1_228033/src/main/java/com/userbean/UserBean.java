package com.userbean;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@ManagedBean
@SessionScoped
public class UserBean {
    private String name;
    private String username;
    private String password;
    private String repassword;
    private String gender;
    private List<String> skills = new ArrayList<>();
    private String contactNo;
    private String email;
    private String college;

    private List<User> userList = new ArrayList<>();

   

 
    public void submit() {
        if (!password.equals(repassword)) {
            System.out.println("Password mismatch");
            return;
        }

        String skillsAsString = String.join(", ", skills);

        try (Connection connection = DatabaseUtil.getConnection()) {
            String sql = "INSERT INTO users (name, username, password, gender, skills, contact_no, email, college) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, name);
            statement.setString(2, username);
            statement.setString(3, password);
            statement.setString(4, gender);
            statement.setString(5, skillsAsString);
            statement.setString(6, contactNo);
            statement.setString(7, email);
            statement.setString(8, college);
            statement.executeUpdate();

           
            userList.add(new User(name, username, gender, skills, contactNo, email, college));
        } catch (SQLException e) {
            e.printStackTrace();
            
        }
    }

   
    public void loadUsers() {
        userList.clear();
        try (Connection connection = DatabaseUtil.getConnection()) {
            String sql = "SELECT * FROM users";
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                String skillsFromDB = resultSet.getString("skills");
                List<String> skillsList = List.of(skillsFromDB.split(", "));

                userList.add(new User(
                        resultSet.getString("name"),
                        resultSet.getString("username"),
                        resultSet.getString("gender"),
                        skillsList,
                        resultSet.getString("contact_no"),
                        resultSet.getString("email"),
                        resultSet.getString("college")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public static class User {
        private String name;
        private String username;
        private String gender;
        private List<String> skills;
        private String contactNo;
        private String email;
        private String college;

        public User(String name, String username, String gender, List<String> skills, String contactNo, String email, String college) {
            this.name = name;
            this.username = username;
            this.gender = gender;
            this.skills = skills;
            this.contactNo = contactNo;
            this.email = email;
            this.college = college;
        }

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getUsername() {
			return username;
		}

		public void setUsername(String username) {
			this.username = username;
		}

		public String getGender() {
			return gender;
		}

		public void setGender(String gender) {
			this.gender = gender;
		}

		public List<String> getSkills() {
			return skills;
		}

		public void setSkills(List<String> skills) {
			this.skills = skills;
		}

		public String getContactNo() {
			return contactNo;
		}

		public void setContactNo(String contactNo) {
			this.contactNo = contactNo;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		public String getCollege() {
			return college;
		}

		public void setCollege(String college) {
			this.college = college;
		}

      
    }
}
